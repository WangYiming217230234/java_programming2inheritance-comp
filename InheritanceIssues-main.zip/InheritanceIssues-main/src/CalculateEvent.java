public class CalculateEvent {

    public double calculateEventCost() {
        // Add your logic here
        return 5000.0;
    }

}
