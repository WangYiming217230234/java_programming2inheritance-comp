package prog2.exercise5.collections;

public enum Books {
    Carrie("001", "Carrie", "Stephen King", 272, "Horror", 3.98, 1974, "Wings", 14),
    Firm("002", "The Firm", "Robin Waterfield / John Grisham", 448, "Thriller", 4.01, 1991, "Addison Wesley Publishing Company", 25),
    Slaughterhouse("003", "Slaughterhouse-Five", "Kurt Vonnegut Jr", 275, "Sci-Fi", 4.1, 1969, "Dial Press", 18),
    Gatsby("004", "The Great Gatsby", "F. Scott Fitzgerald", 188, "Classic", 3.91, 1925, "Scribner", 8),
    Gods("005", "American Gods", "Neil Gaiman", 635, "Fantasy", 4.11, 2001, "Harper Collins", 11);

    private final String bookID;
    private final String bookTitle;
    private final String author;
    private final int pageCount;
    private final String genre;
    private final double averageRating;
    private final int publicationYear;
    private final String publisher;
    private final int bookRent;

    Books(String bookID, String bookTitle, String author, int pageCount, String genre, double averageRating,
          int publicationYear, String publisher, int bookRent) {
        this.bookID = bookID;
        this.bookTitle = bookTitle;
        this.author = author;
        this.pageCount = pageCount;
        this.genre = genre;
        this.averageRating = averageRating;
        this.publicationYear = publicationYear;
        this.publisher = publisher;
        this.bookRent = bookRent;
    }

    public String getBookID() {
        return bookID;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getAuthor() {
        return author;
    }

    public int getPageCount() {
        return pageCount;
    }

    public String getGenre() {
        return genre;
    }

    public double getAverageRating() {
        return averageRating;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getBookRent() {
        return bookRent;
    }
}